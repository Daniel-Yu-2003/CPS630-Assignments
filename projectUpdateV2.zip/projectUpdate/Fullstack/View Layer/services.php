<?php
session_start();
include '../Model/db.php';

$mode = "user";
if(isset($_SESSION['user_id'])){
    $userId = $_SESSION["user_id"];
    $query = $conn->prepare("SELECT mode FROM Users WHERE user_id = ?");
    $query->bind_param("i", $userId);
    $query->execute();
    $query->bind_result($mode);
    $query->fetch();
    $query->close();
    }
?>

<!DOCTYPE html>
<html>
<head>
    <title>Electro - Services</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../../styles.css">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>

    <style>
        .disabled-cart {
            pointer-events: none;
            opacity: 0.5;
        }

        .container {
            min-height: 80vh;
        }
    </style>
</head>

<body style="min-height: 100vh; margin: 0; display: flex; flex-direction: column;">
    <div id="nav-container">
        <h2 id="logo">Electro</h2>
        <nav>
            <a href="./home.php">Home</a>
            <a href="./about-us.php">About Us</a>
            <?php if (isset($_SESSION['user_id'])): ?>
                <a href="profile.php">Profile</a>
                <a href="./logout.php">Log Out</a>
            <?php else: ?>
                <a href="../Controller Layer/sign-in.php">Sign In</a>
                <a href="../Controller Layer/register.php">Sign Up</a>
            <?php endif; ?>
            <a href="./review.php">Reviews</a>
            <a href="./services.php" class="active">Services</a>
        </nav>
    </div>

    <div class="name" style="margin-top: 25px;">
        <h1 style="margin: 0;">Current Coupons</h1>
    </div>

    <div class="container">
    <div class="shopping-container">
            <div class="product-container">
                <?php 
                $sql = "SELECT * FROM Coupons";
                $result = $conn->query($sql);
                
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<div class="product" data-coupon="' . htmlspecialchars($row["coupon_description"]) . '" draggable="true" data-discount="' . $row["discount"] . '" data-threshold="' . $row["min_threshold"] . '" ondragstart="drag(event)">';
                        echo '<h3>' . htmlspecialchars($row["coupon_description"]) . '</h3>';
                        echo '<p>$' . number_format($row["discount"], 2) . '</p>';
                        echo '</div>';
                    }
                } else {
                    echo '<p>No coupons available.</p>';
                }
                ?>
            </div>
            <div style="bottom: 8.5%; right: 20px;" id="cart-button" onclick="toggleCart()" class="<?php echo isset($_SESSION['user_id']) ? '' : 'disabled-cart'; ?>" >
                🛒 Cart
            </div>

            <div id="cart-container" style="max-height: 70%; overflow-y: auto; border: 1px solid #ccc;">
                <h3 id="cart-title">Shopping Cart</h3>
                <table id="cartcontent" style="width: 100%; border-collapse: collapse;">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Quantity</th>
                            <th>Price</th>
                        </tr>
                    </thead>
                    <tbody id="cart-items"></tbody>
                </table>

                <br>
                
                <h4 id="coupon-title" style="display: none;">Coupons</h4>
                <table id="couponcontent" style="width: 100%; border-collapse: collapse; display: none;">
                    <thead>
                        <tr>
                            <th>Details</th>
                            <th>Eligibility</th>
                            <th>Discount</th>
                        </tr>
                    </thead>
                    <tbody id="coupon-items"></tbody>
                </table>

                <h4 id="subtotal">Subtotal: $0</h4>
                <button id="checkout-btn" onclick="submitCartToCheckout()">Proceed to Delivery</button>
                <h5>Click on an item to remove</h5>
                <div id="cart" ondrop="drop(event)" ondragover="allowDrop(event)">
                    <p>Drop items here</p>
                </div> 
            </div>        
        </div>
    </div>

    <footer style="position: relative; background-color:#333; color:white; text-align:center; padding:30px; bottom:0; width:100%;">
        <div id="browser-info"></div>
    </footer>
    
    <script>
        let cart = JSON.parse(localStorage.getItem('cart')) || {};
        localStorage.setItem('cart', JSON.stringify(cart));

        function allowDrop(event) {
            event.preventDefault();
        }

        function drag(event) {
            let item = event.target.closest('.product');
            if (!item) return;
            let itemName = item.getAttribute("data-coupon");
            let itemPrice = parseFloat(item.getAttribute("data-discount"));
            let threshold = parseFloat(item.getAttribute("data-threshold"))

            event.dataTransfer.setData("name", itemName);
            event.dataTransfer.setData("price", itemPrice);
            event.dataTransfer.setData("threshold", threshold);
        }

        function drop(event) {
            event.preventDefault();
            let itemName = event.dataTransfer.getData("name");
            let itemPrice = parseFloat(event.dataTransfer.getData("price"));
            let threshold = parseFloat(event.dataTransfer.getData("threshold"));
            addCouponToCart(itemName, itemPrice, threshold);
        }

        function addCouponToCart(couponName, discount, threshold) {
            if (cart[couponName]) {

            } 
            
            else {
                for (let coupon in cart) {
                    if (cart[coupon].discount) {
                        delete cart[coupon];
                    }
                }

                let subTotal = parseFloat(document.getElementById("subtotal").textContent.split("$")[1]);

                if (subTotal < threshold) {
                    cart[couponName] = { eligibility: "No", discount: -discount, threshold: threshold };
                }

                else {
                    cart[couponName] = { eligibility: "Yes", discount: -discount, threshold: threshold };
                }
                
            }
            
            localStorage.setItem('cart', JSON.stringify(cart)); 
            updateCart();
        }

        function removeItemFromCart(itemName) {
            if (cart[itemName].quantity > 1) {
                cart[itemName].quantity -= 1;
            } else {
                delete cart[itemName];
            }
            localStorage.setItem('cart', JSON.stringify(cart)); 
            updateCart();
        }

        function updateCart() {
            let cartTable = document.getElementById("cart-items");
            let couponTable = document.getElementById("coupon-items");
            let couponTitle = document.getElementById("coupon-title");
            let couponContent = document.getElementById("couponcontent");

            cartTable.innerHTML = "";
            couponTable.innerHTML = "";
            let subtotal = 0;
            let hasCoupons = false;

            Object.keys(cart).forEach((itemName) => {
                let item = cart[itemName];
                if (item.price) {
                    let row = document.createElement("tr");
                    row.innerHTML = `
                        <td>${itemName}</td>
                        <td>${item.quantity}</td>
                        <td>$${item.price.toFixed(2)}</td>
                    `;
                    row.addEventListener("click", () => removeItemFromCart(itemName));
                    cartTable.appendChild(row);

                    subtotal += item.price * item.quantity;
                }
            });

            Object.keys(cart).forEach((itemName) => {
                let item = cart[itemName];
                if (!item.price) {
                    hasCoupons = true;

                    let eligibility = "Yes";
                    if (subtotal < item.threshold) {
                        eligibility = "No";
                    }

                    let row = document.createElement("tr");
                    row.innerHTML = `
                        <td style="font-size: 12px;">${itemName}</td>
                        <td>${eligibility}</td>
                        <td>$${item.discount.toFixed(2)}</td>
                    `;
                    row.addEventListener("click", () => removeItemFromCart(itemName));
                    couponTable.appendChild(row);

                    if (eligibility === "Yes") {
                        subtotal += item.discount;
                    }
                }
            });

            document.getElementById("subtotal").innerText = `Subtotal: $${subtotal.toFixed(2)}`;

            if (hasCoupons) {
                couponTitle.style.display = "";
                couponContent.style.display = "";
            } else {
                couponTitle.style.display = "none";
                couponContent.style.display = "none";
            }
        }


        function toggleCart() {
            let cartBox = document.getElementById("cart-container");
            cartBox.classList.toggle("open");
        }

        function submitCartToCheckout() {
            const cart = JSON.parse(localStorage.getItem('cart')) || {};

            if (Object.keys(cart).length === 0) {
                alert("Cart is empty!");
                return;
            }

            for (let itemName in cart) {
                let item = cart[itemName];
                if (item.eligibility) {
                    if (item.eligibility == "No") {
                        alert("Please Delete Ineligible Coupons");
                        return;
                    }
                }
            };

            const form = document.createElement("form");
            form.method = "POST";
            form.action = "../Controller Layer/checkout.php";

            const input = document.createElement("input");
            input.type = "hidden";
            input.name = "cart_data";
            input.value = JSON.stringify(cart);

            form.appendChild(input);
            document.body.appendChild(form);
            form.submit();
        }

        document.querySelectorAll('.dropdown-toggle').forEach(dropBtn => {
            dropBtn.addEventListener('click', function (e) {
                e.stopPropagation();
                const menu = this.nextElementSibling;
                menu.classList.toggle('show');

                // Close others if multiple dropdowns (optional)
                document.querySelectorAll('.dropdown-menu').forEach(m => {
                    if (m !== menu) m.classList.remove('show');
                });

                // Close on outside click
                document.addEventListener('click', function outsideClickListener(event) {
                    if (!menu.contains(event.target)) {
                        menu.classList.remove('show');
                        document.removeEventListener('click', outsideClickListener);
                    }
                });
            });
        });

        // Initial render
        updateCart();
    </script>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js" crossorigin="anonymous"></script>

    <script src="../../browserDetect.js"></script>
</body>
</html>
