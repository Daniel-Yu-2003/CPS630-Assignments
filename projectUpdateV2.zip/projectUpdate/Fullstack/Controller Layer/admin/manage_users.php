<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../../Model/db.php';

// DELETE
if (isset($_GET['delete_user'])) {
    $id = $_GET['delete_user'];
    $stmt = $conn->prepare("DELETE FROM Users WHERE user_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: dashboard.php?page=users");
    exit();
}

// UPDATE
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_user'])) {
    $id       = $_POST['user_id'];
    $name     = $_POST['name'];
    $email    = $_POST['email'];
    $phone    = $_POST['phone'];
    $address  = $_POST['address'];
    $cityCode = $_POST['city_code'];
    $mode     = $_POST['mode'];

    $stmt = $conn->prepare("UPDATE Users SET name=?, email=?, phone=?, address=?, city_code=?, mode=? WHERE user_id=?");
    $stmt->bind_param("ssssisi", $name, $email, $phone, $address, $cityCode, $mode, $id);
    $stmt->execute();

    header("Location: dashboard.php?page=users&message=User updated successfully");
    exit();
}

// FETCH users
$users = $conn->query("SELECT user_id, name, email, phone, address, city_code, mode FROM Users");

// EDIT mode
$editUser = null;
if (isset($_GET['edit_user'])) {
    $editId = $_GET['edit_user'];
    $stmt = $conn->prepare("SELECT * FROM Users WHERE user_id = ?");
    $stmt->bind_param("i", $editId);
    $stmt->execute();
    $result = $stmt->get_result();
    $editUser = $result->fetch_assoc();
}
?>

<h3>👥 Manage User Accounts</h3>


<?php if ($editUser): ?>
    <form method="POST" class="mb-4">
        <input type="hidden" name="user_id" value="<?= $editUser['user_id'] ?>">
        <div class="form-row">
            <div class="form-group col-md-6">
                <label>Name</label>
                <input type="text" name="name" value="<?= htmlspecialchars($editUser['name']) ?>" class="form-control" required>
            </div>
            <div class="form-group col-md-6">
                <label>Email</label>
                <input type="email" name="email" value="<?= htmlspecialchars($editUser['email']) ?>" class="form-control" required>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group col-md-4">
                <label>Phone</label>
                <input type="text" name="phone" value="<?= htmlspecialchars($editUser['phone']) ?>" class="form-control" required>
            </div>
            <div class="form-group col-md-4">
                <label>City Code</label>
                <input type="number" name="city_code" value="<?= $editUser['city_code'] ?>" class="form-control" required>
            </div>
            <div class="form-group col-md-4">
                <label>Mode</label>
                <select name="mode" class="form-control" required>
                    <option value="User" <?= $editUser['mode'] === 'User' ? 'selected' : '' ?>>User</option>
                    <option value="Admin" <?= $editUser['mode'] === 'Admin' ? 'selected' : '' ?>>Admin</option>
                </select>
            </div>
        </div>

        <div class="form-group">
            <label>Address</label>
            <textarea name="address" class="form-control" required><?= htmlspecialchars($editUser['address']) ?></textarea>
        </div>

        <button type="submit" name="update_user" class="btn btn-success">Update User</button>
        <a href="dashboard.php?page=users" class="btn btn-secondary ml-2">Cancel</a>
    </form>
<?php endif; ?>


<table class="table table-bordered table-striped">
    <thead class="thead-dark">
        <tr>
            <th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Address</th><th>City Code</th><th>Mode</th><th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php while($row = $users->fetch_assoc()): ?>
        <tr>
            <td><?= $row['user_id'] ?></td>
            <td><?= htmlspecialchars($row['name']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td><?= htmlspecialchars($row['phone']) ?></td>
            <td><?= htmlspecialchars($row['address']) ?></td>
            <td><?= $row['city_code'] ?></td>
            <td><?= $row['mode'] ?></td>
            <td>
                <a href="dashboard.php?page=users&edit_user=<?= $row['user_id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                <a href="dashboard.php?page=users&delete_user=<?= $row['user_id'] ?>" class="btn btn-sm btn-danger"
                   onclick="return confirm('Are you sure you want to delete this user?')">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>
