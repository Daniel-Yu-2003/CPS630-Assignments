<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../../Model/db.php';

// Fetch all orders with user info
$orders = $conn->query("
    SELECT o.order_id, o.user_id, u.name AS customer_name, o.total_amount, o.address, o.order_date, o.payment_method
    FROM Orders o
    LEFT JOIN Users u ON o.user_id = u.user_id
    ORDER BY o.order_date DESC
");

// View single order details
$orderDetails = [];
if (isset($_GET['view_order'])) {
    $orderId = intval($_GET['view_order']);

    $stmt = $conn->prepare("
        SELECT od.quantity, od.price, i.item_name
        FROM OrderDetails od
        JOIN Items i ON od.item_id = i.item_id
        WHERE od.order_id = ?
    ");
    $stmt->bind_param("i", $orderId);
    $stmt->execute();
    $orderDetails = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}
?>

<h3>📄 Manage Orders</h3>

<?php if (!empty($orderDetails)): ?>
    <div class="mb-4">
        <h5>Order Details (Order ID: <?= $_GET['view_order'] ?>)</h5>
        <table class="table table-bordered table-sm">
            <thead class="thead-light">
                <tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr>
            </thead>
            <tbody>
                <?php $total = 0; ?>
                <?php foreach ($orderDetails as $item): 
                    $lineTotal = $item['quantity'] * $item['price'];
                    $total += $lineTotal;
                ?>
                <tr>
                    <td><?= htmlspecialchars($item['item_name']) ?></td>
                    <td><?= $item['quantity'] ?></td>
                    <td>$<?= number_format($item['price'], 2) ?></td>
                    <td>$<?= number_format($lineTotal, 2) ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <p><strong>Subtotal:</strong> $<?= number_format($total, 2) ?></p>
        <p><strong>Total (incl. 13% tax):</strong> $<?= number_format($total * 1.13, 2) ?></p>
        <a href="dashboard.php?page=orders" class="btn btn-secondary mt-2">← Back to Orders</a>
    </div>
<?php endif; ?>

<table class="table table-bordered table-striped">
    <thead class="thead-dark">
        <tr>
            <th>ID</th>
            <th>Customer</th>
            <th>Total</th>
            <th>Payment</th>
            <th>Address</th>
            <th>Date</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php while($row = $orders->fetch_assoc()): ?>
        <tr>
            <td><?= $row['order_id'] ?></td>
            <td><?= htmlspecialchars($row['customer_name'] ?? 'N/A') ?></td>
            <td>$<?= number_format($row['total_amount'], 2) ?></td>
            <td><?= htmlspecialchars($row['payment_method']) ?></td>
            <td><?= htmlspecialchars($row['address']) ?></td>
            <td><?= date('M d, Y H:i', strtotime($row['order_date'])) ?></td>
            <td>
                <a href="dashboard.php?page=orders&view_order=<?= $row['order_id'] ?>" class="btn btn-sm btn-info">View</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>
