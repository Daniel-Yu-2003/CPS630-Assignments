<?php
include './Model/db.php';

$conn->query("SET FOREIGN_KEY_CHECKS = 0");

$sql = "DROP TABLE IF EXISTS OrderDetails, Orders , Trips, Users, Items, Trucks, Reviews, ServiceReviews, Coupons";
if ($conn->query($sql)) {
    echo "Existing tables dropped successfully<br>";
} else {
    echo "Error dropping tables: " . $conn->error . "<br>";
}

$conn->query("SET FOREIGN_KEY_CHECKS = 1");

$sql = "CREATE TABLE Trucks (
    truck_id INT AUTO_INCREMENT PRIMARY KEY,
    truck_code VARCHAR(50),
    availability_code INT
)";

if ($conn->query($sql)) {
    echo "Trucks Table created successfully<br>";
} else {
    echo "Error creating Trucks Table: " . $conn->error . "<br>";
}

$sql = "CREATE TABLE Users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(255),
    salt VARCHAR(255),
    address TEXT,
    phone VARCHAR(15),
    city_code INT,
    mode ENUM('Admin', 'User') NOT NULL DEFAULT 'User'
)";

if ($conn->query($sql)) {
    echo "Users Table created successfully<br>";
} 

else {
    echo "Error creating Users Table: " . $conn->error . "<br>";
}

$sql = 'INSERT INTO Users (name, email, password, salt, address, phone, city_code, mode)
VALUES (
    "Admin User",
    "admin@gmail.com",
    "4950cdc3007a48afde3a68f4de41bb91",
    "2ff09aa4c9ef8cf7",
    "123 Admin St",
    "1234567890",
    1001,
    "Admin"
)';

if ($conn->query($sql)) {
    echo "Admin User inserted successfully<br>";
} else {
    echo "Error inserting Admin User: " . $conn->error . "<br>";
}

$sql = "CREATE TABLE Items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    item_name VARCHAR(255) NOT NULL,
    item_price DECIMAL(10,2) NOT NULL,
    item_image TEXT NOT NULL
)";

if ($conn->query($sql)) {
    echo "Items Table created successfully<br>";
} else {
    echo "Error creating Items Table: " . $conn->error . "<br>";
}

$sql = "INSERT INTO Items (item_name, item_price, item_image) VALUES
('iPhone 15', 1200.00, 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxIRERASEBIPDxAQFRIVFRAPFRAVEBAQFRIWFhURFRUYHSggGBolGxUVITEhJSkrLi4uFx8zODMsNygtLisBCgoKDg0OFQ8NFS4ZFRktLS0rKy0tKysrKysrKy0rKysrLSstKy0rNysrLSs3LTcrKystNysrKy0tKy0rLS0tK//AABEIAL4BCQMBIgACEQEDEQH/xAAcAAEAAQUBAQAAAAAAAAAAAAAABwEDBAUGAgj/xABNEAACAQIBBgYNCAkCBwEAAAAAAQIDBBEFBxIhMVEGQWFxgZETIjI0NVRyc5OhsbKzFyMzQlKSwdMkJWJ0gsLR0uEUtBZDU2SDhPAI/8QAFwEBAQEBAAAAAAAAAAAAAAAAAAECA//EABsRAQEAAwEBAQAAAAAAAAAAAAABAhExQSES/9oADAMBAAIRAxEAPwCcQAAAAAAAAAABj3lxGnGU5yUIQTlKUtUYxSxbb3EZZdzk1pOf+jUKNGG2vXS0uSXbNRhzPF82wCVQQHUzgX3j61/ZhSw6MKZa+UG+8ff3KX5Q0bfQIIAp8Pb+Xc30pPco2+PU6eJ7/wCOMo+N1fuW/wDYBPgPn644f5Qgm5XlRJfs2/8AYeskcJuEN6tO0deVF4pVqytadKXLHSgnLofQBP4IRubjhPTWlK4tUtiWlRbb5O1KUbrhRLZXtul0l/KE3E3ghSU+FCeDubNPc50E/XE89l4T+NWf37f+0G4m0EIO44Ua/wBJtZYfZlQeHVErb3PCeeOFxa4ribop+6DcTcCGNPhUtfZrWWHEpUMX1xwPdlnPv7KrCllq0dOE3grimlr3tSi9CfkrB+wKmQGLYXcK0IVKc1Up1IqUJx1xlF600ZQAAAAAAAAAAAAAAAAAAAAABwGeDKLhb0KEXg7ibb5YU8NX3pwf8JCGX8oYSwj3NOU4U09kdB6M6uHHOUk9e7Bb8Zbz1v5zJ+3/AJ/N3dAhO7hp+UpVNW9Obbw5SosQvKuOLctax7bZJPj5uUzuz44cqT6H/nHqMKEXho6L8qWyK53sRSD0ppQxkopLVxpa8etsqV3GUeCip2ruNPScIuUtmitHDHBbVt1PF44GltK+ksHra495i3F/cSpKjOrVdBYfNtrR1bE3hi1yNlMnPtnzfigNjkjJsb3KFpa1MXSnKU6iX1qdKDqOOPFjhh1E+wgopRilGMUkoxSUYxWpRSWxJEMZuV+uKHmLnr0WiXsrVtCjUa26OC53q/EyrUur2eq39SOqK5Fx9Jt6lCTp1I02oVJQmoT+xUcWoy6Hg+g1WQaeEUdDSiacZ9+vme54BZV05aVldVJYvGcY6ak29ctNYqWO/EtPgFlTxC89FI+pYxK6JHT9PnzgBwMynSv7WpK3r2tOnNSq1aq0IyofXp4PutJJxwW/HVhiTBeU3BqcdTRv5xMC9p4plZyu3u2rKcVJcfFue4xMvZHp3tvVtqqTjVi0nqxhUw7SpHc09ZZyTV0Zypvj1rnNxTWtc69pl0xu44v/APP+U5ztbi1qNuVpUWGP1VUck4/epyf8TJVIdzFd9ZY86+b6Wp/UmIKAAAAAAAAAAAAAAAAAAAAAIqz2fSZP/wDP79AhSuk9JftS95k0Z8u6scNujc+9QIXue6lytvDdi8WixmsWpSlscpNbm2Xa8+xxjCOrFJyfHKT4m9yFSbbbk230aluKVcJ4a0pJJYPVpJbGnv5C0jxCcoSetNJ4NxeMJb0nxm0ya/nJLcvU8Ga+bajFTajCOyKab5kun1mbkROTnNrBPUgrrM3Hhij5i59jJV4USwt3yyivaRXm38MUf3e49jJS4Wr9Gb3Sh+JPUy48ZE7hG9pHO5Cn2qN/GrGKxlKMVvk0l6y1yxZaK4GA8s261OtT6Hj7C5TypQlsq030/wBSNsmSMW4jqMuE09aaa5HiWa8Qlc3XloVYy3P1HQ0tq50aTKtLUbPI9XThTfGsE+hirhfHC5iu+ssedfxahMRDuYvvvLHnX8WoTER0AAAAAAAAAAAAAAAAAAAAAEVZ7V29j5Nz71Aie6slLn3krZ66idWyjxqnXfJhKdFL3WRqVGnlkv8AafrLc8kN/WZvMDzgBpqGRVj2zbW43NKmorBakiqRUDbZtfDFHzFz7GS3wipaVtWXGkn1NMiXNp4Yo+YufYyR84GVnb2rjDVUuMacX9mGHby6ml/FyD0vHJT4TunHsdBJ1Njm9ai9y3ssULatXelVnOTe9sw8h2Oxs7SwtkkjTlzjBtMhrj1mxp5FjuNtQpGXCBFaWnYThrhKUeZs2FvlOce1rLSX2lt/yZ6pnitbpojTHvUpRxTxT4y1waq9tKG5prrwZ4adN6L7iXqe8tZLehdRXFJ4FZ5XN5i++8sedfxahMRDOY2qlfZVhrxnUqSWzDCFZp/Ej6yZjLqAAAAAAAAAAAAAAAAAAAAAIjz0d82vmanxYEdkiZ5++bXzFT4sCPMCopgMD0AKYFGeijA2ubLwxR8xc+xnSZy6undUocVOC65Nt+rA5zNk/wBc0f3e591m/wCHsf06Xkw91AvFMj08EjqLVHM5NnhgdDa1S7c23pGTAwqUzJhIisiLPTLKkHMKxsoxxizU0avb0JcanFPnUsDZXtTUznqFbXzVI+1CJk1GZPwnlHnu/wDcUSbSEcyL/WWUP/b/ANxRJuI6AAAAAAAAAAAAAAAAAAAAACK89MF2WyeCxdO4TfG0p0cF631kbElZ6fpLHyLn3qBGpUAABQs1qmp6ODfRqLd/LBJbzXsDrM1nhihjr/R7nWuZnW5w6GFzGX2oR9Wr8DkM03ha3/d7r+YkfODbJuhLj1p78McV+JBy9lsNvb1sCxZ2moyJWzQZsbO3uDOp1TnVNxMqjeFZb1VDzUqmtV4WK96Da5lK6wizTZIenOK26VWC9ZiZWv8AUzb5urR1Jqo+5py0sf2nqiva+gp1gZjacf8AW5XlgtKNSai+NRlWk5Jc+hD7qJkIdzGd95Y86/jVCYjLqAAAAAAAAAAAAAAAAAAAAAIsz0/SWPkXPvUCNiSc9X0lj5Fz71AjUqAAAs3VLSjq2rWjVuDeOp6uRm6PLA2WaXwtb46v0e6/mJEv27js1XiTWit0IvBEa8BqmjlLS41a3XrTX4ku5FtsaWi/rJrrQGJY23aoyZWheydDtcONauozuxmRoLiwNXcWridhOkYVxaplTTj6lWS3mBc3TOmvMnmivbHAJpzl5WbJUzZ0dGzi/tVZPqUV+BGV1QwJe4E0NCytlvTl1zZVkcLmM77yx51/GqExEO5jO/MsedfxqhMRGgAAAAAAAAAAAAAAAAAAAABFmer6Sx8i596gRqSVnq+ksfIufeoEalQAKAVPLKlJAXuCPhGP7vX9pNmRO4iQxwJhjlLD/tbl9WsmXIcu0iBkKno1Zrf2y6dvrxMtRPF7DuZri1Pmf+faXIPFGRblEs1ImVIszQGuuKZosoU9p0NwaHKT2lHKXsO2w5SY8k2/Y6VCH2IQXSksfXiRbkq2Va7owfc6cXLmT/8AkS7HaucERNmM77yx51/GqExEO5jO/MsedfxqhMQUAAAAAAAAAAAAAAAAAAAAARZnq+ksfIufeoEaElZ6+7sfIufeoEaFRUFMQBUowUYG1zbU9LK9OP2ra6XXBolTg/PVhubIwzVv9dUPMXPsZJ1vHsdxWp8Sk2vJete0FdHFJrB60zEwcHovoe9GTRkXKtJTWD6+NPkIMRyLVSR5r0akOJzjvjt6Ua6vfJbcVzkHu6qHM5XucEzYVq1Sq9GlCc3+ynh1mbkrgu1JVbnCUlrjSWuKe+T4+Yo0eT7KVGnGrLVObUkuNRT1f16iTLWqpqElskovrWJy+XqWMGbXgnX07aljti3Hqf8AkER5mM78yx51/GqExEO5jO/MsedfxqhMQUAAAAAAAAAAAAAAAAAAAAARXnr7ux8i596gRoSXnr7ux8i596gRoVAAACkipRgbnNZ4aoeYufYyV+EdLQr06vFNaL8qOz1ewinNZ4aoeYufYybstWXZqMorul20fKXF0610kFizqYpGbFnPZGusUk9q1NG+pSCL6DWO1J85RDEKYluoXC3UA02V12r5ivAV/MzW6q/ZE85ZnhCRf4FUtG2jL/qVJy6MVFe6CODzGd+ZY86/jVCYiHcxnfmWPOv41QmIKAAAAAAAAAAAAAAAAAAAAAIuz1p6Vi+LRuV040MPx6iMScc5mQpXdp80nKtQl2WEFtqJRcZ01vbi20uNxiQamVFSgAFSkgUYG4zY1Ust2qf16VzFcr7HKeHUmT+fLquqttcW93QWNW2qKajxTWydN+VHV18ZP/BjhxY38Iyo16cKjXbW9aUYV6b404t9slvWKIrxlm07DV7LBfN1H22GyM3/AF/qbCyr4pGwrdjnFxk4SjJYNYrYc3Wg7aXdKdJvtZpp4cktzCV0SkesTW297GS2rrRkqut660BkNlqrItyuFvXWjW5RynGK2pt7EtrYGBlyo5uNKGudRqKS5TrbG3VOFOnHZBRjz4cZpMh2Sg3Xrygqkl2sXKPzcXv5X6jnc4Wci3taNSjaVYXN9VThCNGSnGi5anUqSWpNcUduOGOrWCNRmHelcZYmu5dVNPepVa2HusmI4LM5wZlYWEVVTjXuH2ScXqlCOGEINcTwxbT1pyw4jvQoAAAAAAAAAAAAAAAAAAAAA8Thictwj4A2t5KVRrsFaW2rRWDk98o46MnytY8p1gAjB5oY8V5Lpor+8p8kK8cl6FfmEoACL/khXjkvQr8wfJCvHJehX5hKAAi6WZ6L23kvQr+8xa2Y6jPXK6cnvdFJ9amm+klsAQ98gtt4zL0cvzB8gtv41L0cvzCYQBD3yC2/jUvRy/MHyC2/jUvRy/MJhAEPfILb+NS9HL8wfILb+NS9HL8wmEAQ+swttx3M/Rv8w6vgrmzsbCSnCCrVo7KtVYuL3xjjop8uGPKdqAPEIYHsAAAAAAAAAAAAP//Z'),
('MacBook Air', 1300.00, 'https://m.media-amazon.com/images/I/71nXzKOZRuL.jpg'),
('Samsung Galaxy A06', 240.00, 'https://cellularsavings.ca/cdn/shop/files/Samsung-Galaxy-A06-Light-Blue_480x480.jpg?v=1727987813'),
('Apple Watch SE', 330.00, 'https://store.storeimages.cdn-apple.com/1/as-images.apple.com/is/MYJ33ref_VW_34FR+watch-case-40-aluminum-starlight-nc-se_VW_34FR+watch-face-40-aluminum-starlight-se_VW_34FR?wid=752&hei=720&bgc=fafafa&trim=1&fmt=p-jpg&qlt=80&.v=L1VPMlk5ZkpkOVFZR3Fud25vckh4RStGZUJWLzNFUFVydllxZFp0d1M4NktoaXQwYi9wRGFOV2FsZVA1S1dYc3U0MnNvUmFpbmpuWFJpcHZlcmRSWXdScEJ3QjIyVnl6dGRLV0ozWGQvU3RmSGlnNkpTM1NGVHN6YWcySEw0THd4cVNUNDJadDNVSmRncE9SalAvZ24zZmdHMUt6VFlqa3BpV2VBOUNycGdrcDIxSk5peW5HTWQ0c004MmJwMkNtdGl6SHg4ZE5NYmlWSVQ5akRTdGpCYXdFcFI4ZnVKTUUyODRESjZvdEp1NA'),
('Apple iPad', 440.00, 'https://m.media-amazon.com/images/I/61uA2UVnYWL._AC_UF894,1000_QL80_.jpg')";

if ($conn->query($sql)) {
    echo "Items inserted successfully<br>";
} else {
    echo "Error inserting items: " . $conn->error . "<br>";
}

$sql = "CREATE TABLE Trips (
    trip_id INT AUTO_INCREMENT PRIMARY KEY,
    source_code INT,
    destination_code INT,
    distance_km DECIMAL(10, 2),
    truck_id INT,
    price DECIMAL(10, 2),
    FOREIGN KEY (truck_id) REFERENCES Trucks(truck_id)
)";

if ($conn->query($sql)) {
    echo "Trips Table created successfully<br>";
} else {
    echo "Error creating Trips Table: " . $conn->error . "<br>";
}

$sql = "CREATE TABLE Orders (
    order_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    total_amount DECIMAL(10, 2),
    address VARCHAR(255),
    order_date DATETIME,
    payment_method VARCHAR(50),
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
)";

if ($conn->query($sql)) {
    echo "Orders Table created successfully<br>";
} else {
    echo "Error creating Orders Table: " . $conn->error . "<br>";
}

$sql = "CREATE TABLE OrderDetails (
    order_detail_id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    item_id INT,
    quantity INT,
    price DECIMAL(10,2),
    FOREIGN KEY (order_id) REFERENCES Orders(order_id),
    FOREIGN KEY (item_id) REFERENCES Items(item_id)
);
";
if ($conn->query($sql)) {
    echo "OrderDetails Table created successfully<br>";
} else {
    echo "Error creating OrderDetails Table: " . $conn->error . "<br>";
}

$sql = "CREATE TABLE Reviews (
    review_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    item_id INT,
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    review_text TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(user_id),
    FOREIGN KEY (item_id) REFERENCES Items(item_id)
)";

if ($conn->query($sql)) {
    echo "Reviews Table created successfully<br>";
} else {
    echo "Error creating Reviews Table: " . $conn->error . "<br>";
}

$sql = "INSERT INTO Reviews (user_id, item_id, rating, review_text) VALUES
(1, 1, 5, 'Amazing phone! The camera is outstanding.'),
(1, 1, 4, 'Battery life could be better.'),
(1, 1, 3, 'Overpriced, but smooth performance.'),
(1, 2, 5, 'Super lightweight and powerful.'),
(1, 2, 4, 'Wish it had more ports.')";

if ($conn->query($sql)) {
    echo "Sample reviews inserted successfully<br>";
} else {
    echo "Error inserting reviews: " . $conn->error . "<br>";
}

$sql = "CREATE TABLE ServiceReviews (
    review_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    rating INT CHECK (rating BETWEEN 1 AND 5),
    review_text VARCHAR(255),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(user_id)
)";

if ($conn->query($sql)) {
    echo "ServiceReviews table created successfully<br>";
} else {
    echo "Error creating ServiceReviews table: " . $conn->error . "<br>";
}

$sql = "INSERT INTO ServiceReviews (user_id, rating, review_text) VALUES
(1, 5, 'Great delivery service!'),
(1, 4, 'Friendly support team.'),
(1, 3, 'Slight delay but overall good'),
(1, 2, 'Had to wait a bit longer than expected'),
(1, 1, 'Not satisfied with the delivery timing')";

if ($conn->query($sql)) {
    echo "Dummy service reviews inserted<br>";
} else {
    echo "Error inserting service reviews: " . $conn->error . "<br>";
}

$sql = "CREATE TABLE Coupons (
    coupon_id INT AUTO_INCREMENT PRIMARY KEY,
    discount INT,
    min_threshold INT,
    coupon_description VARCHAR(255)
)";

if ($conn->query($sql)) {
    echo "Coupons table created successfully<br>";
} else {
    echo "Error creating Coupons table: " . $conn->error . "<br>";
}

$sql = "INSERT INTO Coupons (discount, min_threshold, coupon_description) VALUES
(100, 1000, 'Get $100 off when you spend $1000 or more'),
(40, 500, 'Get $40 off when you spend $500 or more'),
(1500, 10000, 'Get $1500 off when you spend $10000 or more')";

if ($conn->query($sql)) {
    echo "Coupons inserted<br>";
} 

else {
    echo "Error inserting coupons: " . $conn->error . "<br>";
}

$conn->close();
?>