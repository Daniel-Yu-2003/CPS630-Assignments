<?php
session_start();
include '../../Model/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['mode'] !== 'Admin') {
    header("Location: ../../View Layer/home.php");
    exit();
}

$allowed_pages = [
    'items' => 'manage_items.php',
    'users' => 'manage_users.php',
    'orders' => 'manage_orders.php',
    'reviews' => 'manage_reviews.php',
    'truck_trips' => 'manage_truck_trips.php',
    'services' => 'manage_services.php'
];

$page = $_GET['page'] ?? 'items';
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }
        .admin-header {
            background-color: #343a40;
            color: white;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .admin-content {
            padding: 30px;
        }

        .dropdown-menu a {
            color: #212529;
        }

        .dropdown-menu a:hover {
            background-color: #f1f1f1;
        }
    </style>
</head>
<body>
    <!-- Top Admin Bar -->
    <div class="admin-header">
        <h4>⚙️ Admin Dashboard</h4>

        <div class="dropdown">
            <button class="btn btn-light dropdown-toggle" type="button" id="adminMenu" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Manage Sections
            </button>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="adminMenu">
                <a class="dropdown-item" href="dashboard.php?page=items">📦 Manage Items</a>
                <a class="dropdown-item" href="dashboard.php?page=users">👥 Manage Users</a>
                <a class="dropdown-item" href="dashboard.php?page=orders">📄 Manage Orders</a>
                <a class="dropdown-item" href="dashboard.php?page=reviews">📝 Manage Reviews</a>
                <a class="dropdown-item" href="dashboard.php?page=truck_trips">🚛 Manage Trucks & Trips</a>
                <a class="dropdown-item" href="dashboard.php?page=services">🎟️ Manage Services</a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item text-danger" href="../../index.html">← Back to Home</a>
            </div>
        </div>
    </div>

    <!-- Admin Main Content -->
    <div class="admin-content">
        <?php if (isset($_GET['message'])): ?>
            <div class="alert alert-success">
                <?= htmlspecialchars($_GET['message']) ?>
            </div>
        <?php endif; ?>
        <?php
        if (array_key_exists($page, $allowed_pages)) {
            include __DIR__ . '/' . $allowed_pages[$page];
        } else {
            echo "<div class='alert alert-warning'>⚠ Invalid page requested.</div>";
        }
        ?>
    </div>


    </div>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.min.js"></script>

</body>
</html>
