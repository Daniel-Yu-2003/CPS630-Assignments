<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../../Model/db.php';

if (!isset($_SESSION["user_id"]) || $_SESSION['mode'] !== 'Admin') {
    header("Location: ../../View Layer/home.php");
    exit();
}

// Handle Search
$searchTerm = $_GET['search'] ?? '';
if (!empty($searchTerm)) {
    $stmt = $conn->prepare("SELECT * FROM Coupons WHERE Coupon_Description LIKE ?");
    $likeTerm = "%" . $searchTerm . "%";
    $stmt->bind_param("s", $likeTerm);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT * FROM Coupons");
}

// Create
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create'])) {
    $couponDescription = $_POST['coupon_description'];
    $minThreshold = $_POST['min_threshold'];
    $discount = $_POST['discount'];

    $stmt = $conn->prepare("INSERT INTO Coupons (coupon_description, min_threshold, discount) VALUES (?, ?, ?)");
    $stmt->bind_param("sdd", $couponDescription, $minThreshold, $discount);
    $stmt->execute();
    header("Location: dashboard.php?page=services&message=Coupon added successfully");
    exit();
}

// Edit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit'])) {
    $id = $_POST['coupon_id'];
    $description = $_POST['coupon_description'];
    $minThreshold = $_POST['min_threshold'];
    $discount = $_POST['discount'];

    $stmt = $conn->prepare("UPDATE Coupons SET coupon_description = ?, min_threshold = ?, discount = ? WHERE coupon_id = ?");
    $stmt->bind_param("sddi", $description, $minThreshold, $discount, $id);
    $stmt->execute();
    header("Location: dashboard.php?page=services&message=Coupon updated successfully");
    exit();
}

// Delete
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM Coupons WHERE coupon_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: dashboard.php?page=services&message=Coupon deleted successfully");
    exit();
}

// Load item for edit
$editItem = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $stmt = $conn->prepare("SELECT * FROM Coupons WHERE coupon_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultEdit = $stmt->get_result();
    $editItem = $resultEdit->fetch_assoc();
}
?>

<div class="container mt-4">
    <h2 style="margin-bottom: 25px;">🎟️ Manage Services</h2>

    <?php if (isset($_GET['message'])): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($_GET['message']); ?></div>
    <?php endif; ?>

    <form method="GET" class="form-inline mb-4">
        <input type="hidden" name="page" value="services">
        <label class="mr-2 font-weight-bold">Search:</label>
        <input type="text" name="search" class="form-control mr-2" value="<?php echo htmlspecialchars($searchTerm); ?>">
        <button type="submit" class="btn btn-info">Go</button>
    </form>

    <form method="POST">
        <input type="hidden" name="coupon_id" value="<?php echo $editItem['coupon_id'] ?? ''; ?>">

        <div class="form-group">
            <label>Coupon Description:</label>
            <input type="text" name="coupon_description" class="form-control" required value="<?php echo $editItem['coupon_description'] ?? ''; ?>">
        </div>
        <div class="form-group">
            <label>Minimum Price Threshold:</label>
            <input type="number" step="0.01" name="min_threshold" class="form-control" required value="<?php echo $editItem['min_threshold'] ?? ''; ?>">
        </div>
        <div class="form-group">
            <label>Discount:</label>
            <input type="number" name="discount" class="form-control" required value="<?php echo $editItem['discount'] ?? ''; ?>">
        </div>
        <button type="submit" name="<?php echo $editItem ? 'edit' : 'create'; ?>" class="btn btn-<?php echo $editItem ? 'warning' : 'primary'; ?>">
            <?php echo $editItem ? 'Update Coupon' : 'Add Coupon'; ?>
        </button>
        <?php if ($editItem): ?>
            <a href="dashboard.php?page=services" class="btn btn-secondary ml-2">Cancel</a>
        <?php endif; ?>
    </form>

    <h4 class="mt-5">Coupon List</h4>
    <table class="table table-bordered table-striped">
        <thead class="thead-dark">
            <tr>
                <th>Coupon Description</th>
                <th>Minimum Price Threshold</th>
                <th>Discount</th>
                <th style="width: 150px;">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['coupon_description']); ?></td>
                    <td>$<?php echo number_format($row['min_threshold'], 2); ?></td>
                    <td>$<?php echo number_format($row['discount'], 2); ?></td>
                    <td>
                        <a href="dashboard.php?page=services&edit=<?php echo $row['coupon_id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                        <a href="dashboard.php?page=services&delete=<?php echo $row['coupon_id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
