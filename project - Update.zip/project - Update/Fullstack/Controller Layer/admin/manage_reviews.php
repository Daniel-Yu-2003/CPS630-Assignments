<?php
if (session_status() === PHP_SESSION_NONE) session_start();
include '../../Model/db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['mode'] !== 'Admin') {
    header("Location: ../../View Layer/home.php");
    exit();
}

if (isset($_GET['delete_review'])) {
    $id = $_GET['delete_review'];
    $stmt = $conn->prepare("DELETE FROM Reviews WHERE review_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: dashboard.php?page=reviews&message=Product review deleted");
    exit();
}

if (isset($_GET['delete_service_review'])) {
    $id = $_GET['delete_service_review'];
    $stmt = $conn->prepare("DELETE FROM ServiceReviews WHERE review_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: dashboard.php?page=reviews&message=Service review deleted");
    exit();
}

$productReviews = $conn->query("
    SELECT r.review_id, r.review_text, r.rating, r.created_at, 
           i.item_name, u.name 
    FROM Reviews r
    JOIN Items i ON r.item_id = i.item_id
    JOIN Users u ON r.user_id = u.user_id
    ORDER BY r.created_at DESC
");

$serviceReviews = $conn->query("
    SELECT sr.review_id, sr.review_text, sr.rating, sr.created_at, 
           u.name 
    FROM ServiceReviews sr
    JOIN Users u ON sr.user_id = u.user_id
    ORDER BY sr.created_at DESC
");
?>

<h3 style="margin-bottom: 25px;">📝 Manage All Reviews</h3>

<?php if (isset($_GET['message'])): ?>
    <div class="alert alert-success"><?= htmlspecialchars($_GET['message']) ?></div>
<?php endif; ?>

<!-- Nav tabs -->
<ul class="nav nav-tabs mb-4" role="tablist">
    <li class="nav-item">
        <a class="nav-link active" id="product-tab" data-toggle="tab" href="#product-reviews" role="tab">🛍 Product Reviews</a>
    </li>
    <li class="nav-item">
        <a class="nav-link" id="service-tab" data-toggle="tab" href="#service-reviews" role="tab">🧰 Service Reviews</a>
    </li>
</ul>

<!-- Tab content -->
<div class="tab-content">
    <!-- Product Reviews -->
    <div class="tab-pane fade show active" id="product-reviews" role="tabpanel">
        <table class="table table-bordered table-striped">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Product</th>
                    <th>User</th>
                    <th>Rating</th>
                    <th>Review</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($row = $productReviews->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['review_id'] ?></td>
                    <td><?= htmlspecialchars($row['item_name']) ?></td>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= str_repeat("⭐", $row['rating']) ?></td>
                    <td><?= htmlspecialchars($row['review_text']) ?></td>
                    <td><?= date('Y-m-d', strtotime($row['created_at'])) ?></td>
                    <td>
                        <a href="dashboard.php?page=reviews&delete_review=<?= $row['review_id'] ?>" 
                           class="btn btn-sm btn-danger"
                           onclick="return confirm('Delete this review?')">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <!-- Service Reviews -->
    <div class="tab-pane fade" id="service-reviews" role="tabpanel">
        <table class="table table-bordered table-striped">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>User</th>
                    <th>Rating</th>
                    <th>Review</th>
                    <th>Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($row = $serviceReviews->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['review_id'] ?></td>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= str_repeat("⭐", $row['rating']) ?></td>
                    <td><?= htmlspecialchars($row['review_text']) ?></td>
                    <td><?= date('Y-m-d', strtotime($row['created_at'])) ?></td>
                    <td>
                        <a href="dashboard.php?page=reviews&delete_service_review=<?= $row['review_id'] ?>" 
                           class="btn btn-sm btn-danger"
                           onclick="return confirm('Delete this service review?')">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

