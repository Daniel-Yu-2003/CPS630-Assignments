<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

include '../../Model/db.php';

if (!isset($_SESSION["user_id"]) || $_SESSION['mode'] !== 'Admin') {
    header("Location: ../../View Layer/home.php");
    exit();
}

// Handle Search
$searchTerm = $_GET['search'] ?? '';
if (!empty($searchTerm)) {
    $stmt = $conn->prepare("SELECT * FROM Items WHERE item_name LIKE ?");
    $likeTerm = "%" . $searchTerm . "%";
    $stmt->bind_param("s", $likeTerm);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query("SELECT * FROM Items");
}

// Create
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create'])) {
    $name = $_POST['item_name'];
    $price = $_POST['item_price'];
    $image = $_POST['item_image'];

    $stmt = $conn->prepare("INSERT INTO Items (item_name, item_price, item_image) VALUES (?, ?, ?)");
    $stmt->bind_param("sds", $name, $price, $image);
    $stmt->execute();
    header("Location: dashboard.php?page=items&message=Item added successfully");
    exit();
}

// Edit
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit'])) {
    $id = $_POST['item_id'];
    $name = $_POST['item_name'];
    $price = $_POST['item_price'];
    $image = $_POST['item_image'];

    $stmt = $conn->prepare("UPDATE Items SET item_name = ?, item_price = ?, item_image = ? WHERE item_id = ?");
    $stmt->bind_param("sdsi", $name, $price, $image, $id);
    $stmt->execute();
    header("Location: dashboard.php?page=items&message=Item updated successfully");
    exit();
}

// Delete
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM Items WHERE item_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: dashboard.php?page=items&message=Item deleted successfully");
    exit();
}

// Load item for edit
$editItem = null;
if (isset($_GET['edit'])) {
    $id = $_GET['edit'];
    $stmt = $conn->prepare("SELECT * FROM Items WHERE item_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultEdit = $stmt->get_result();
    $editItem = $resultEdit->fetch_assoc();
}
?>

<div class="container mt-4">
    <h2 style="margin-bottom: 25px;">📦 Manage Items</h2>

    <?php if (isset($_GET['message'])): ?>
        <div class="alert alert-success"><?php echo htmlspecialchars($_GET['message']); ?></div>
    <?php endif; ?>

    <form method="GET" class="form-inline mb-4">
        <input type="hidden" name="page" value="items">
        <label class="mr-2 font-weight-bold">Search:</label>
        <input type="text" name="search" class="form-control mr-2" value="<?php echo htmlspecialchars($searchTerm); ?>">
        <button type="submit" class="btn btn-info">Go</button>
    </form>

    <form method="POST">
        <input type="hidden" name="item_id" value="<?php echo $editItem['item_id'] ?? ''; ?>">

        <div class="form-group">
            <label>Item Name:</label>
            <input type="text" name="item_name" class="form-control" required value="<?php echo $editItem['item_name'] ?? ''; ?>">
        </div>
        <div class="form-group">
            <label>Item Price:</label>
            <input type="number" step="0.01" name="item_price" class="form-control" required value="<?php echo $editItem['item_price'] ?? ''; ?>">
        </div>
        <div class="form-group">
            <label>Item Image URL:</label>
            <input type="text" name="item_image" class="form-control" required value="<?php echo $editItem['item_image'] ?? ''; ?>">
        </div>
        <button type="submit" name="<?php echo $editItem ? 'edit' : 'create'; ?>" class="btn btn-<?php echo $editItem ? 'warning' : 'primary'; ?>">
            <?php echo $editItem ? 'Update Item' : 'Add Item'; ?>
        </button>
        <?php if ($editItem): ?>
            <a href="dashboard.php?page=items" class="btn btn-secondary ml-2">Cancel</a>
        <?php endif; ?>
    </form>

    <h4 class="mt-5">Item List</h4>
    <table class="table table-bordered table-striped">
        <thead class="thead-dark">
            <tr>
                <th>Name</th>
                <th>Price</th>
                <th>Image</th>
                <th style="width: 150px;">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['item_name']); ?></td>
                    <td>$<?php echo number_format($row['item_price'], 2); ?></td>
                    <td><img src="<?php echo htmlspecialchars($row['item_image']); ?>" width="60"></td>
                    <td>
                        <a href="dashboard.php?page=items&edit=<?php echo $row['item_id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                        <a href="dashboard.php?page=items&delete=<?php echo $row['item_id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</div>
