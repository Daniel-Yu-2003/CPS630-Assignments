<?php
session_start();
include '../Model/db.php';

if (isset($_POST['mode'])) {
    $mode = $_POST['mode'];
    $user_id = $_SESSION["user_id"];
    
    $sql = "UPDATE users SET mode = ? WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('si', $mode, $user_id);
    
    if ($stmt->execute()) {
        $_SESSION['mode'] = $mode;
        header("Location: profile.php");
        exit();
    } else {
        echo "Error updating mode: " . $conn->error;
    }
}

$sql = "SELECT mode FROM Users WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $user_id);
$stmt->execute();
$stmt->bind_result($updatedMode);
$stmt->fetch();
echo "Updated Mode: " . $updatedMode;
exit();

$conn->close();
?>