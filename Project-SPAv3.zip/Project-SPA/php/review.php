<?php
session_start();
include '../Model/db.php';

// Detect mode (Admin/User)
$mode = "user";
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION["user_id"];
    $query = $conn->prepare("SELECT mode FROM Users WHERE user_id = ?");
    $query->bind_param("i", $userId);
    $query->execute();
    $query->bind_result($mode);
    $query->fetch();
    $query->close();
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rating = $_POST['rating'];
    $text = $_POST['review_text'];

    if (isset($_POST['submit_review'])) {
        $itemId = $_POST['item_id'];
        $stmt = $conn->prepare("INSERT INTO Reviews (user_id, item_id, rating, review_text) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiis", $_SESSION['user_id'], $itemId, $rating, $text);
        $stmt->execute();
        $stmt->close();
        header("Location: review.php?message=Item review submitted&tab=product");
        exit();
    }

    if (isset($_POST['submit_service_review'])) {
        $stmt = $conn->prepare("INSERT INTO ServiceReviews (user_id, rating, review_text) VALUES (?, ?, ?)");
        $stmt->bind_param("iis", $_SESSION['user_id'], $rating, $text);
        $stmt->execute();
        $stmt->close();
        header("Location: review.php?message=Service review submitted&tab=service");
        exit();
    }
}

$activeTab = $_GET['tab'] ?? 'product'; // Default tab
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reviews | Electro</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../styles.css">
    <style>
        body { background-color: #f8f9fa; }
        .container {
            max-width: 800px;
            margin: auto;
            padding-bottom: 60px;
            min-height: 85vh;
        }
        .review-box {
            background: #fff;
            border: 1px solid #ddd;
            box-shadow: 0 2px 6px rgba(0,0,0,0.05);
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .review-header { font-weight: bold; font-size: 17px; margin-bottom: 6px; }
        .review-meta { font-size: 14px; color: #888; margin-bottom: 10px; }
        .star-rating { color: #f4c542; font-size: 18px; letter-spacing: 1px; }
        .rating-sort { margin-top: 20px; }
        .sort { margin-top: 20px; }
    </style>
</head>
<body>

<div id="nav-container">
    <h2 id="logo">Electro</h2>
    <nav>
        <a href="../index.html">Home</a>
        <a href="../index.html#!aboutus">About Us</a>
        <?php if(isset($_SESSION['user_id'])): ?>
            <a href="../index.html#!profile">Profile</a>
            <a href="./logout.php">Log Out</a>
        <?php else: ?>
            <a href="../index.html#!signin">Sign In</a>
            <a href="../index.html#!register">Sign Up</a>
        <?php endif; ?>
        <a href="./review.php">Reviews</a>
        <a href="../index.html#!services">Services</a>
        <?php if($mode === 'Admin'): ?>
            <a href="./admin/dashboard.php">
                <img style="width: 25px;" src="../Images/database_15458462.png" alt="Dashboard" />
            </a>
        <?php endif; ?>
    </nav>
</div>

<div class="container mt-4">
    <h2 class="text-center mb-4">Reviews</h2>

    <?php if (isset($_GET['message'])): ?>
        <div class="alert alert-success text-center"><?= htmlspecialchars($_GET['message']) ?></div>
    <?php endif; ?>

    <!-- Tabs -->
    <ul class="nav nav-tabs">
        <li class="nav-item">
            <a class="nav-link <?= $activeTab === 'product' ? 'active' : '' ?>" href="review.php?tab=product">🛍 Product Reviews</a>
        </li>
        <li class="nav-item">
            <a class="nav-link <?= $activeTab === 'service' ? 'active' : '' ?>" href="review.php?tab=service">🧰 Service Reviews</a>
        </li>
    </ul>

    <div class="tab-content">
        <!-- Product Reviews -->
        <div class="tab-pane fade <?= $activeTab === 'product' ? 'show active' : '' ?>" id="product">
            <form method="GET" class="form-inline mb-4 justify-content-center sort">
                <input type="hidden" name="tab" value="product">
                <label class="mr-2">Filter by Product:</label>
                <select name="item_id" class="form-control mr-2" onchange="this.form.submit()">
                    <option value="">-- All Products --</option>
                    <?php
                    $itemList = $conn->query("SELECT item_id, item_name FROM Items");
                    while ($item = $itemList->fetch_assoc()):
                        $selected = (isset($_GET['item_id']) && $_GET['item_id'] == $item['item_id']) ? 'selected' : '';
                    ?>
                        <option value="<?= $item['item_id'] ?>" <?= $selected ?>><?= htmlspecialchars($item['item_name']) ?></option>
                    <?php endwhile; ?>
                </select>
            </form>

            <?php
            $filter = isset($_GET['item_id']) && is_numeric($_GET['item_id']) ? "WHERE r.item_id = " . intval($_GET['item_id']) : "";
            $productReviews = $conn->query("
                SELECT r.review_id, r.rating, r.review_text, r.created_at, i.item_name, u.name 
                FROM Reviews r 
                JOIN Items i ON r.item_id = i.item_id 
                JOIN Users u ON r.user_id = u.user_id 
                $filter
                ORDER BY r.rating ASC
            ");
            ?>

            <?php while ($row = $productReviews->fetch_assoc()): ?>
                <div class="review-box">
                    <div class="review-header"><?= htmlspecialchars($row['item_name']) ?></div>
                    <div class="review-meta">by <strong><?= htmlspecialchars($row['name']) ?></strong> on <?= date('M d, Y', strtotime($row['created_at'])) ?></div>
                    <p><?= htmlspecialchars($row['review_text']) ?></p>
                    <div class="star-rating"><?= str_repeat("⭐", $row['rating']) ?></div>
                </div>
            <?php endwhile; ?>

            <?php if (isset($_SESSION['user_id'])): ?>
                <h4 class="mt-5">Leave a Product Review</h4>
                <form method="POST" class="mt-3">
                    <div class="form-group">
                        <label>Product</label>
                        <select name="item_id" class="form-control" required>
                            <?php
                            $items = $conn->query("SELECT item_id, item_name FROM Items");
                            while ($item = $items->fetch_assoc()):
                            ?>
                                <option value="<?= $item['item_id'] ?>"><?= htmlspecialchars($item['item_name']) ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Review</label>
                        <input type="text" name="review_text" class="form-control" maxlength="100" required>
                    </div>
                    <div class="form-group">
                        <label>Ranking (1–5)</label>
                        <select name="rating" class="form-control" required>
                            <option value="5">⭐⭐⭐⭐⭐</option>
                            <option value="4">⭐⭐⭐⭐</option>
                            <option value="3">⭐⭐⭐</option>
                            <option value="2">⭐⭐</option>
                            <option value="1">⭐</option>
                        </select>
                    </div>
                    <button type="submit" name="submit_review" class="btn btn-primary">Submit Review</button>
                </form>
            <?php endif; ?>
        </div>

        <!-- Service Reviews -->
        <div class="tab-pane fade <?= $activeTab === 'service' ? 'show active' : '' ?>" id="service">
            <form method="GET" class="form-inline mb-4 justify-content-center sort">
                <input type="hidden" name="tab" value="service">
                <label class="mr-2">Sort by Rating:</label>
                <select name="sort_service" class="form-control" onchange="this.form.submit()">
                    <option value="asc" <?= ($_GET['sort_service'] ?? '') === 'asc' ? 'selected' : '' ?>>Lowest First</option>
                    <option value="desc" <?= ($_GET['sort_service'] ?? '') === 'desc' ? 'selected' : '' ?>>Highest First</option>
                </select>
            </form>

            <?php
            $sort = ($_GET['sort_service'] ?? 'asc') === 'desc' ? 'DESC' : 'ASC';
            $serviceReviews = $conn->query("
                SELECT sr.review_id, sr.rating, sr.review_text, sr.created_at, u.name 
                FROM ServiceReviews sr 
                JOIN Users u ON sr.user_id = u.user_id 
                ORDER BY sr.rating $sort
            ");
            ?>

            <?php while ($row = $serviceReviews->fetch_assoc()): ?>
                <div class="review-box">
                    <div class="review-header">Service Review</div>
                    <div class="review-meta">by <strong><?= htmlspecialchars($row['name']) ?></strong> on <?= date('M d, Y', strtotime($row['created_at'])) ?></div>
                    <p><?= htmlspecialchars($row['review_text']) ?></p>
                    <div class="star-rating"><?= str_repeat("⭐", $row['rating']) ?></div>
                </div>
            <?php endwhile; ?>

            <?php if (isset($_SESSION['user_id'])): ?>
                <h4 class="mt-5">Leave a Service Review</h4>
                <form method="POST" class="mt-3">
                    <div class="form-group">
                        <label>Review</label>
                        <input type="text" name="review_text" class="form-control" maxlength="100" required>
                    </div>
                    <div class="form-group">
                        <label>Ranking (1–5)</label>
                        <select name="rating" class="form-control" required>
                            <option value="5">⭐⭐⭐⭐⭐</option>
                            <option value="4">⭐⭐⭐⭐</option>
                            <option value="3">⭐⭐⭐</option>
                            <option value="2">⭐⭐</option>
                            <option value="1">⭐</option>
                        </select>
                    </div>
                    <button type="submit" name="submit_service_review" class="btn btn-secondary">Submit Service Review</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>

<footer style="background-color:#333; color:white; text-align:center; padding:30px;">
    <div id="browser-info"></div>    
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="../../browserDetect.js"></script>
</body>
</html>
