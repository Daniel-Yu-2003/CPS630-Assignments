<?php
    session_start();

    include '../Model/db.php';

    $userId = $_SESSION["user_id"];
    $query = $conn->prepare("INSERT INTO Orders (user_id, total_price, date_issued, date_received, payment_code, trip_id, receipt_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $query->execute();
    $query->bind_param("idsssii", $userId, $totalPrice, $dateIssued, $dateReceived, $paymentCode, $tripId, $receiptId);
    if ($query->fetch()) {
        //user data found
    }

    else {
        echo "Error Retrieving Data";
        exit();
    }
    $query->close();
    $conn->close();
?>

<html>
    <head>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
        <script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.slim.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
        <link rel="stylesheet" href="styles.css">
    </head>
    <body>
        <h1>Payment Information</h1>
        <form id="paymentForm">
            <div>
                <label for="name">Name on Card:</label>
                <input type="text" id="name" required>
            </div>
            <div>
                <label for="number">Card Number:</label>
                <input type="text" id="number" pattern="^\d{16}$" required title="credit card number is 16 digits">
            </div>
            <div>
                <label for="expire-date">Expiration Date:</label>
                <input type="month" id="expire-date" required>
            </div>
            <div>
                <label for="cvv">CVV:</label>
                <input type="text" id="cvv" pattern="^\d{3}$"required title="cvv is 3 digits">
            </div>
            <button type="submit">Review Invoice</button>
        </form>
        <a href="map.html">Go back to choosing destination</a>
        <script>
            document.getElementById("paymentForm").addEventListener("submit", function(e){
                e.preventDefault();
                const name = document.getElementById("name").value;
                localStorage.setItem('custName', name);
                window.location.replace("invoice.php");
            })
        </script>
    </body>
</html>
