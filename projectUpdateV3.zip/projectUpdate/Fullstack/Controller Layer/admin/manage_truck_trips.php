<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include '../../Model/db.php';

// Insert dummy truck
if (isset($_GET['add_dummy_truck'])) {
    $conn->query("INSERT INTO Trucks (truck_code, availability_code) VALUES ('TRUCK-" . rand(100, 999) . "', 1)");
    header("Location: dashboard.php?page=truck_trips");
    exit();
}

// Delete truck
if (isset($_GET['delete_truck'])) {
    $id = $_GET['delete_truck'];
    $stmt = $conn->prepare("DELETE FROM Trucks WHERE truck_id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    header("Location: dashboard.php?page=truck_trips");
    exit();
}

// Fetch data
$trucks = $conn->query("SELECT * FROM Trucks");
$trips = $conn->query("SELECT Trips.*, Trucks.truck_code FROM Trips LEFT JOIN Trucks ON Trips.truck_id = Trucks.truck_id");
?>

<h3>🚚 Truck & Trip Management</h3>

<!-- Dummy Truck Button -->
<a href="dashboard.php?page=truck_trips&add_dummy_truck=1" class="btn btn-primary mb-3">➕ Add Dummy Truck</a>

<!-- Trucks Table -->
<h5 class="mt-4">🛻 Truck List</h5>
<table class="table table-bordered table-striped">
    <thead class="thead-dark">
        <tr>
            <th>ID</th>
            <th>Truck Code</th>
            <th>Availability</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($row = $trucks->fetch_assoc()): ?>
            <tr>
                <td><?= $row['truck_id'] ?></td>
                <td><?= htmlspecialchars($row['truck_code']) ?></td>
                <td><?= $row['availability_code'] ? 'Available' : 'Unavailable' ?></td>
                <td>
                    <a href="dashboard.php?page=truck_trips&delete_truck=<?= $row['truck_id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Delete this truck?')">Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>

<!-- Trips Table -->
<h5 class="mt-5">🗺️ Trip Records</h5>
<table class="table table-bordered table-hover">
    <thead class="thead-light">
        <tr>
            <th>Trip ID</th>
            <th>From (City Code)</th>
            <th>To (City Code)</th>
            <th>Distance (km)</th>
            <th>Price</th>
            <th>Truck Code</th>
        </tr>
    </thead>
    <tbody>
        <?php while ($trip = $trips->fetch_assoc()): ?>
            <tr>
                <td><?= $trip['trip_id'] ?></td>
                <td><?= $trip['source_code'] ?></td>
                <td><?= $trip['destination_code'] ?></td>
                <td><?= $trip['distance_km'] ?> km</td>
                <td>$<?= number_format($trip['price'], 2) ?></td>
                <td><?= htmlspecialchars($trip['truck_code'] ?? 'N/A') ?></td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>
