<?php
session_start();
include '../Model/db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['cart_data'])) {
    $cart = json_decode($_POST['cart_data'], true);
    if (!$cart || !is_array($cart)) {
        echo "<script>alert('Your cart is empty or invalid'); window.location.href='../View Layer/home.php';</script>";
        exit();
    }

    $_SESSION['cart'] = $cart;
    $_SESSION['paid'] = false;
    unset($_SESSION['custName'], $_SESSION['address'], $_SESSION['payment_method']);
}

if (isset($_POST['confirm_payment'])) {
    $_SESSION['custName'] = $_POST['name'] ?? 'Guest';
    $_SESSION['address'] = $_POST['address'] ?? 'N/A';
    $_SESSION['payment_method'] = $_POST['payment_method'] ?? 'unknown';
    $_SESSION['paid'] = true;
    echo "<script>
            localStorage.removeItem('cart');
        </script>";
    $isAdmin = false;
    $userId = $_SESSION['user_id'] ?? null;

    if ($userId) {
        $stmt = $conn->prepare("SELECT mode FROM Users WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $stmt->bind_result($mode);
        $stmt->fetch();
        $stmt->close();
        $isAdmin = ($mode === 'Admin');
    }

    if (!$isAdmin && $userId) {
        $res = $conn->query("SELECT address FROM Users WHERE mode = 'Admin' AND user_id != " . intval($userId) . " LIMIT 1");
        $_SESSION['warehouse_address'] = $res->fetch_assoc()['address'] ?? 'Yonge Dundas Square, Toronto';
    } else {
        $_SESSION['warehouse_address'] = 'Yonge Dundas Square, Toronto';
    }

    $subtotal = 0;

    foreach ($_SESSION['cart'] as $key => $item) {
        if (isset($item['price']) && isset($item['quantity'])) {
            $subtotal += $item['price'] * $item['quantity'];
        } 
        
        else if (isset($item['discount'])) {
            $threshold = $item['min_threshold'] ?? 0;
    
            if ($subtotal >= $threshold) {
                $subtotal -= abs($item['discount']);
            }
        }
    }

    $grandTotal = $subtotal * 1.13;

    $stmt = $conn->prepare("INSERT INTO Orders (user_id, total_amount, address, order_date, payment_method) VALUES (?, ?, ?, NOW(), ?)");
    $stmt->bind_param("idss", $userId, $grandTotal, $_SESSION['address'], $_SESSION['payment_method']);
    $stmt->execute();
    $orderId = $stmt->insert_id;
    $stmt->close();

    // Insert into OrderDetails table
    foreach ($_SESSION['cart'] as $itemName => $item) {
        if (isset($item['price']) && isset($item['quantity'])) {
            $stmt = $conn->prepare("SELECT item_id FROM Items WHERE item_name = ?");
            $stmt->bind_param("s", $itemName);
            $stmt->execute();
            $stmt->bind_result($itemId);
            $stmt->fetch();
            $stmt->close();
    
            if ($itemId) {
                $stmt = $conn->prepare("INSERT INTO OrderDetails (order_id, item_id, quantity, price) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("iiid", $orderId, $itemId, $item['quantity'], $item['price']);
                $stmt->execute();
                $stmt->close();
            }
        }
    }
    

    // Insert dummy truck
    $truckCode = "TRK-" . rand(1000, 9999);
    $availability = 1;

    $stmt = $conn->prepare("INSERT INTO Trucks (truck_code, availability_code) VALUES (?, ?)");
    $stmt->bind_param("si", $truckCode, $availability);
    $stmt->execute();
    $truckId = $stmt->insert_id;
    $stmt->close();

    // Insert dummy trip
    $sourceCode = 1001; 
    $destinationCode = rand(1002, 1010); 
    $distanceKm = rand(10, 100); 
    $tripPrice = $distanceKm * 2.5; 

    $stmt = $conn->prepare("INSERT INTO Trips (source_code, destination_code, distance_km, truck_id, price) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iiidi", $sourceCode, $destinationCode, $distanceKm, $truckId, $tripPrice);
    $stmt->execute();
    $stmt->close();

}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Checkout</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <style>
        body {
            background: #f4f4f4;
            font-family: 'Segoe UI', sans-serif;
        }
        .container {
            max-width: 900px;
        }
        .card {
            border-radius: 12px;
            border: none;
            box-shadow: 0 0 15px rgba(0,0,0,0.05);
            margin-bottom: 30px;
        }
        .table th, .table td {
            vertical-align: middle;
        }
        .table thead {
            background: #f1f1f1;
        }
        .btn-block {
            padding: 12px;
            font-size: 16px;
        }
        #map {
            height: 400px;
        }
        .payment-fields {
            display: none;
            margin-top: 15px;
            border-top: 1px dashed #ccc;
            padding-top: 15px;
        }

    </style>
</head>
<body class="py-5">
<div class="container">
    <h2 class="text-center mb-4">🧾 Checkout</h2>

<?php if (!isset($_SESSION['paid']) || $_SESSION['paid'] === false): ?>
    <!-- Invoice -->
    <div class="card p-4">
        <h5 class="mb-3">Invoice Summary</h5>
        <?php
            // Generate order info
            $orderId = $_SESSION['order_id'] ?? ('ORD-' . rand(10000, 99999));
            date_default_timezone_set('America/New_York');
            $orderDate = $_SESSION['order_date'] ?? date('F j, Y - g:i A');

            // Save to session so it stays the same if page reloads
            $_SESSION['order_id'] = $orderId;
            $_SESSION['order_date'] = $orderDate;
        ?>
        <div class="d-flex justify-content-between align-items-center mb-4 px-1">
            <p class="mb-0"><strong>Order Number:</strong> <?= $orderId ?></p>
            <p class="mb-0 text-muted"><strong>Date:</strong> <?= $orderDate ?></p>
        </div>
        <?php
            $subtotal = 0;
            $appliedDiscount = 0;

            //checks for item or coupon if applicable
            $items = [];
            $coupons = [];
            foreach ($_SESSION['cart'] as $item => $info) {
                if (isset($info['price']) && isset($info['quantity'])) {
                    
                    $items[$item] = $info;
                    $subtotal += $info['price'] * $info['quantity'];
                } 
                
                else if (isset($info['discount'])) {
                    
                    $coupons[$item] = $info;
                }
            }

            
            foreach ($coupons as $coupon) {
                $threshold = $coupon['min_threshold'] ?? 0;
                if ($subtotal >= $threshold) {
                    $appliedDiscount += abs($coupon['discount']);
                    $subtotal -= abs($coupon['discount']);
                }
            }
        ?>
        <table class="table table-bordered">
            <thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead>
            <tbody>
            <?php foreach ($items as $item => $info): ?>
                <tr>
                    <td><?= htmlspecialchars($item) ?></td>
                    <td><?= $info['quantity'] ?></td>
                    <td>$<?= number_format($info['price'], 2) ?></td>
                    <td>$<?= number_format($info['price'] * $info['quantity'], 2) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>

        <?php if (!empty($coupons)): ?>
            <h6>Applied Coupons:</h6>
            <table class="table table-bordered">
                <thead><tr><th>Coupon</th><th>Discount</th></tr></thead>
                <tbody>
                <?php foreach ($coupons as $couponName => $coupon): ?>
                    <tr>
                        <td><?= htmlspecialchars($couponName) ?></td>
                        <td>$<?= number_format(abs($coupon['discount']), 2) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>

        <div class="text-right">
            <p><strong>Subtotal:</strong> $<?= number_format($subtotal, 2) ?></p>
            <p><strong>Tax (13%):</strong> $<?= number_format($subtotal * 0.13, 2) ?></p>
            <h5><strong>Total:</strong> $<?= number_format($subtotal * 1.13, 2) ?></h5>
        </div>
    </div>

    <!-- Payment -->
    <div class="card p-4 shadow-sm">
        <h5 class="mb-4 border-bottom pb-2">Payment Details</h5>

        <form method="POST" id="payment-form">
            <input type="hidden" name="confirm_payment" value="1">

            <div class="form-group">
                <label for="payment_method"><strong>Payment Method</strong></label>
                <select class="form-control custom-select" name="payment_method" id="payment_method" required onchange="toggleFields()">
                    <option value="">-- Select a Payment Type --</option>
                    <option value="credit">Credit Card</option>
                    <option value="debit">Debit Card</option>
                    <option value="cash">Cash</option>
                    <option value="gift">Gift Card</option>
                </select>
            </div>

            <div class="form-group">
                <label for="name"><strong>Full Name</strong></label>
                <input class="form-control" name="name" id="name" placeholder="John Doe" required>
            </div>

            <!-- Hidden fields for final submission -->
            <input type="hidden" name="address" id="final-address">
            <input type="hidden" name="cvv" id="final-cvv">

            <!-- Credit -->
            <div id="credit-fields" class="payment-fields">
                <div class="form-group">
                    <label>Card Number</label>
                    <input class="form-control" placeholder="1234 5678 9012 3456">
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label>CVV</label>
                        <input class="form-control" id="credit-cvv" placeholder="123">
                    </div>
                    <div class="form-group col-md-6">
                        <label>Billing Address</label>
                        <input class="form-control" id="credit-address" placeholder="123 Street, City">
                    </div>
                </div>
            </div>

            <!-- Debit -->
            <div id="debit-fields" class="payment-fields">
                <div class="form-group">
                    <label>Debit Card Number</label>
                    <input class="form-control" placeholder="5678 9012 3456 7890">
                </div>
                <div class="form-group">
                    <label>Billing Address</label>
                    <input class="form-control" id="debit-address" placeholder="456 Avenue, City">
                </div>
            </div>

            <!-- Cash -->
            <div id="cash-fields" class="payment-fields">
                <p class="text-muted">You will pay with cash upon delivery.</p>
                <div class="form-group">
                    <label>Delivery Address</label>
                    <input class="form-control" id="cash-address" placeholder="789 Delivery St, City">
                </div>
            </div>

            <!-- Gift -->
            <div id="gift-fields" class="payment-fields">
                <div class="form-group">
                    <label>Gift Card Code</label>
                    <input class="form-control" placeholder="GFT-123-456">
                </div>
                <div class="form-group">
                    <label>Shipping Address</label>
                    <input class="form-control" id="gift-address" placeholder="Shipping address">
                </div>
            </div>

            <button class="btn btn-success btn-block mt-4 py-2 font-weight-bold">
                Pay
            </button>
        </form>
    </div>


<?php else: ?>
    <!-- Receipt -->
<div class="card p-4">
    <h4 class="text-success">✅ Payment Successful</h4>
    <p>Thank you, <strong><?= htmlspecialchars($_SESSION['custName']) ?></strong>!</p>
    <p>You paid via <strong><?= htmlspecialchars($_SESSION['payment_method']) ?></strong></p>

    <hr>

    <h5 class="mt-3">📦 Order Details</h5>
    <table class="table table-bordered">
        <thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead>
        <tbody>
        <?php
        $subtotal = 0;
        $appliedDiscount = 0;

        //another item and coupon check
        $items = [];
        $coupons = [];
        foreach ($_SESSION['cart'] as $item => $info) {
            if (isset($info['price']) && isset($info['quantity'])) {
                $items[$item] = $info;
                $subtotal += $info['price'] * $info['quantity'];
            } 
            
            else if (isset($info['discount'])) {
                $coupons[$item] = $info;
            }
        }

        // Render items
        foreach ($items as $item => $info):
            $lineTotal = $info['price'] * $info['quantity'];
        ?>
        <tr>
            <td><?= htmlspecialchars($item) ?></td>
            <td><?= $info['quantity'] ?></td>
            <td>$<?= number_format($info['price'], 2) ?></td>
            <td>$<?= number_format($lineTotal, 2) ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <?php if (!empty($coupons)): ?>
        <h6>Applied Coupons:</h6>
        <table class="table table-bordered">
            <thead><tr><th>Coupon</th><th>Discount</th></tr></thead>
            <tbody>
            <?php foreach ($coupons as $couponName => $coupon): ?>
                <tr>
                    <td><?= htmlspecialchars($couponName) ?></td>
                    <td>$<?= number_format(abs($coupon['discount']), 2) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <div class="text-right">
        <?php 

        foreach ($coupons as $coupon) {
            $threshold = $coupon['min_threshold'] ?? 0;
            if ($subtotal >= $threshold) {
                $appliedDiscount += abs($coupon['discount']);
                $subtotal -= abs($coupon['discount']);
            }
        }
        ?>
        <p><strong>Subtotal:</strong> $<?= number_format($subtotal, 2) ?></p>
        <p><strong>Tax (13%):</strong> $<?= number_format($subtotal * 0.13, 2) ?></p>
        <h5><strong>Total (incl. tax):</strong> $<?= number_format($subtotal * 1.13, 2) ?></h5>
        <p><strong>Shipping to:</strong> <?= htmlspecialchars($_SESSION['address']) ?></p>
    </div>

        <hr>

        <h5 class="mt-4">🚚 Truck & Trip Details</h5>
        <?php
        // Fetch latest trip and truck
        $tripSql = "SELECT t.*, tr.truck_code FROM Trips t
                    JOIN Trucks tr ON t.truck_id = tr.truck_id
                    ORDER BY t.trip_id DESC LIMIT 1";
        $tripResult = $conn->query($tripSql);

        $adminCityCode = "N/A";
        $userCityCode = "N/A";

        // Fetch admin city_code
        $adminRes = $conn->query("SELECT city_code FROM Users WHERE mode = 'Admin' LIMIT 1");
        if ($adminRes && $adminRes->num_rows > 0) {
            $adminCityCode = $adminRes->fetch_assoc()['city_code'];
        }

        // Fetch user city_code
        if (isset($_SESSION['user_id'])) {
            $userId = $_SESSION['user_id'];
            $userRes = $conn->query("SELECT city_code FROM Users WHERE user_id = $userId");
            if ($userRes && $userRes->num_rows > 0) {
                $userCityCode = $userRes->fetch_assoc()['city_code'];
            }
        }
        ?>

        <?php if ($tripResult && $tripResult->num_rows > 0):
            $trip = $tripResult->fetch_assoc();
        ?>
        <table class="table table-sm table-striped">
            <tr><th>Truck Code:</th><td><?= htmlspecialchars($trip['truck_code']) ?></td></tr>
            <tr><th>From (Admin - City Code):</th><td><?= htmlspecialchars($adminCityCode) ?></td></tr>
            <tr><th>To (User - City Code):</th><td><?= htmlspecialchars($userCityCode) ?></td></tr>
            <tr><th>Distance (km):</th><td><?= number_format($trip['distance_km'], 2) ?> km</td></tr>
            <tr><th>Delivery Fee:</th><td>$<?= number_format($trip['price'], 2) ?></td></tr>
        </table>
        <?php else: ?>
            <p class="text-danger">❌ Unable to fetch trip/truck info.</p>
        <?php endif; ?>


        <div id="map" class="mt-4 border rounded"></div>

        <a href="../View Layer/home.php" class="btn btn-primary mt-4 btn-block">← Return to Homepage</a>

        <!-- Leaflet Map Scripts -->
        <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css">
        <link rel="stylesheet" href="https://unpkg.com/leaflet-routing-machine/dist/leaflet-routing-machine.css">
        <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
        <script src="https://unpkg.com/leaflet-routing-machine/dist/leaflet-routing-machine.js"></script>
        <script src="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.js"></script>
        <script>
        const warehouse = <?= json_encode($_SESSION['warehouse_address']) ?>;
        const customer = <?= json_encode($_SESSION['address']) ?>;
        const map = L.map('map').setView([43.65, -79.38], 13);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);
        const geocoder = L.Control.Geocoder.nominatim();

        geocoder.geocode(warehouse, wRes => {
            if (!wRes.length) return;
            const wLoc = wRes[0].center;
            geocoder.geocode(customer, cRes => {
                if (!cRes.length) return;
                const cLoc = cRes[0].center;

                L.Routing.control({
                    waypoints: [L.latLng(wLoc.lat, wLoc.lng), L.latLng(cLoc.lat, cLoc.lng)],
                    routeWhileDragging: false
                }).addTo(map);

                L.marker(wLoc).addTo(map).bindPopup("Warehouse");
                L.marker(cLoc).addTo(map).bindPopup("Customer");
                map.fitBounds([wLoc, cLoc]);
            });
        });
        </script>
    </div>

<?php endif; ?>
</div>

<script>
    function toggleFields() {
        document.querySelectorAll('.payment-fields').forEach(d => d.style.display = 'none');
        const method = document.getElementById('payment_method').value;
        if (method) document.getElementById(method + '-fields').style.display = 'block';
    }

    document.getElementById("payment-form")?.addEventListener("submit", function () {
        const method = document.getElementById("payment_method").value;
        let address = '';
        let cvv = '000';
        if (method === 'credit') {
            address = document.getElementById('credit-address').value;
            cvv = document.getElementById('credit-cvv').value;
        } else if (method === 'debit') {
            address = document.getElementById('debit-address').value;
        } else if (method === 'cash') {
            address = document.getElementById('cash-address').value;
        } else if (method === 'gift') {
            address = document.getElementById('gift-address').value;
        }
        document.getElementById('final-address').value = address;
        document.getElementById('final-cvv').value = cvv;
    });


    function toggleFields() {
        document.querySelectorAll('.payment-fields').forEach(field => {
            field.style.display = 'none'; 
        });

        const method = document.getElementById('payment_method').value;
        if (method && document.getElementById(method + '-fields')) {
            document.getElementById(method + '-fields').style.display = 'block'; 
        }
    }

</script>
</body>
</html>
