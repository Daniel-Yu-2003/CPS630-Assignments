<?php
include '../Model/db.php';
session_start();

$error_message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username       = $_POST['username'];
    $email          = $_POST['email'];
    $password       = $_POST["password"];  
    $confirmPassword= $_POST['confirm-password'];
    $homeAddress    = $_POST['home-address'];
    $phoneNumber    = $_POST["phone-number"];  
    $cityCode       = $_POST['city-code'];

    if ($password === $confirmPassword) {
        $salt = bin2hex(random_bytes(8));
        $hashedPassword = md5($salt . $password);

        // Check if username or email already exists
        $stmt = $conn->prepare("SELECT user_id FROM Users WHERE email = ? OR name = ?");
        $stmt->bind_param("ss", $email, $username);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error_message = "Username/Email already taken. Please choose another one.";
        } else {
            // 👉 Check user count
            $countResult = $conn->query("SELECT COUNT(*) AS total FROM Users");
            $row = $countResult->fetch_assoc();
            $userCount = $row['total'];

            // 🎯 First user = Admin, others = User
            $mode = ($userCount == 0) ? 'Admin' : 'User';

            $stmt = $conn->prepare("INSERT INTO Users (name, email, password, salt, address, phone, city_code, mode) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->bind_param("ssssssis", $username, $email, $hashedPassword, $salt, $homeAddress, $phoneNumber, $cityCode, $mode);

            if ($stmt->execute()) {
                // Auto-login after register (optional)
                $_SESSION['user_id'] = $stmt->insert_id;
                $_SESSION['mode'] = $mode;

                echo "<script>
                        alert('User registration successful as $mode');
                        window.location.href = '../index.html#!signin';
                      </script>";
                exit();
            } else {
                $error_message = "Error creating account: " . $stmt->error;
            }
        }

        $stmt->close();
    } else {
        $error_message = "Passwords do not match.";
    }

    $conn->close();
}
?>


<html>
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="../styles.css">
        <style>
            * {
                box-sizing: border-box;
            }

            .container {
                display: flex;
                justify-content: center; 
                align-items: center; 
                height: 100vh; 
            }

            .form-container {
                background: rgba(255, 255, 255, 0.9); 
                padding: 30px;
                border-radius: 10px;
                width: 100%;
                max-width: 400px;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            }

            .form-container h2 {
                text-align: center;
                margin-bottom: 20px;
                font-size: 24px;
                color: #333;
            }

            .form-container input {
                width: 100%;
                padding: 12px;
                margin: 10px 0;
                border: 1px solid #ccc;
                border-radius: 6px;
                font-size: 16px;
                background-color: #f9f9f9;
                transition: all 0.3s ease;
            }

            .form-container input:focus {
                border-color: #f44336; 
                background-color: #fff;
            }

            .form-container button {
                width: 100%;
                padding: 12px;
                background-color: #f44336; 
                border: none;
                border-radius: 6px;
                color: white;
                font-size: 16px;
                cursor: pointer;
                transition: background-color 0.3s ease;
            }

            .form-container button:hover {
                background-color: #d32f2f; 
            }

            .form-container .footer {
                text-align: center;
                margin-top: 15px;
            }

            .form-container .footer a {
                text-decoration: none;
                color: #555;
                font-size: 14px;
                transition: color 0.3s ease;
            }

            .form-container .footer a:hover {
                color: #f44336; 
            }

            .form-container .error {
                color: #f44336;
                font-size: 14px;
                text-align: center;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="form-container">
                <h2>Register</h2>
                <form action="./php/register.php" method="POST">
                    <input type="text" name="username" placeholder="Username *" required>
                    <input type="email" name="email" placeholder="Email Address *" required>
                    <input type="password" name="password" placeholder="Password" required>
                    <input type="password" name="confirm-password" placeholder="Confirm Password" required>
                    <input type="text" name="home-address" placeholder="Home Address" required>
                    <input type="tel" name="phone-number" placeholder="Phone Number" required>
                    <input type="number" name="city-code" placeholder="City Code" required>
                    
                    <button type="submit">Register</button>

                    <?php if (!empty($error_message)): ?>
                        <div class="error" style="margin-top: 20px;">
                            <p><strong>Error:</strong> <?php echo $error_message; ?></p>
                        </div>
                    <?php endif; ?>
            
                    <div class="footer">
                        <a href="#!/signin">Already have an account? Login</a>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>
