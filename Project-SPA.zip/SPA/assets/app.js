var currentUser = null

var app = angular.module('myApp', ['ngRoute']); 

app.config(function($routeProvider) { 
    $routeProvider 
        .when('/', { 
            templateUrl : 'pages/home.html', 
            controller: 'HomeController'
        }) 

        .when('/aboutus', { 
            templateUrl : 'pages/aboutus.html', 
        }) 

        .when('/services', { 
            templateUrl : 'pages/services.html', 
            controller: 'ServiceController'
        }) 

        .when('/signin', { 
            templateUrl : 'php/sign-in.php', 
        }) 

        .when('/profile', { 
            templateUrl : 'php/profile.php', 
        }) 

        .when('/register', { 
            templateUrl : 'php/register.php', 
        }) 



        .otherwise({redirectTo: '/'}); 
}); 

// change active nav link
document.querySelector('nav').addEventListener('click', function(e) {
    if (e.target.classList.contains('link')) {
        const link = e.target;
        
        document.querySelectorAll('.link').forEach(navLink => {
            navLink.classList.remove('active');
        });
        
        link.classList.add('active');
    }
});

app.controller('MainController', function($scope, $http){
    $http.get('api/checkLogin.php')
    .then(function(response) {
        $scope.admin = response.data.admin;
        $scope.isLoggedIn = response.data.loggedin;
        console.log('Login status:', $scope.isLoggedIn);
    })
    .catch(function(error) {
        console.error('Error:', error);
        $scope.items = [];
        $scope.isLoggedIn = false;
    });

    $scope.toggleCart = function() {
        let cartBox = document.getElementById("cart-container");
        cartBox.classList.toggle("open");
    }

    $scope.removeItemFromCart = function(itemName) {
        let cart = JSON.parse(localStorage.getItem('cart')) || {};

        if (!cart[itemName].hasOwnProperty('quantity')){
            delete cart[itemName];
        } else {
            if (cart[itemName].quantity > 1) {
                cart[itemName].quantity -= 1;
            } else {
                delete cart[itemName];
            }
        }
        localStorage.setItem('cart', JSON.stringify(cart)); 
        angular.element(document.getElementById("cart")).scope().updateCart();
    }
});


// show products
app.controller('HomeController', function($scope, $http){
    $http.get('api/items.php')
        .then(function(response) {
            $scope.items = response.data;
        })

    let cart = JSON.parse(localStorage.getItem('cart')) || {};
    localStorage.setItem('cart', JSON.stringify(cart));

    allowDrop = function (event) {
        event.preventDefault();
    }

    drag = function (event) {
        let item = event.target.closest('.product');
        if (!item) return;
        let itemName = item.getAttribute("data-name");
        let itemPrice = parseFloat(item.getAttribute("data-price"));

        event.dataTransfer.setData("name", itemName);
        event.dataTransfer.setData("price", itemPrice);
    }

    drop = function (event) {
        event.preventDefault();
        let itemName = event.dataTransfer.getData("name");
        let itemPrice = parseFloat(event.dataTransfer.getData("price"));
        $scope.addItemToCart(itemName, itemPrice);
    }

    $scope.addItemToCart = function(itemName, itemPrice) {
        let cart = JSON.parse(localStorage.getItem('cart')) || {};
        if (cart[itemName]) {
            cart[itemName].quantity += 1;
        } else {
            cart[itemName] = { price: itemPrice, quantity: 1 };
        }
        localStorage.setItem('cart', JSON.stringify(cart)); 
        $scope.updateCart();
    }

    $scope.updateCart = function() {
        let cart = JSON.parse(localStorage.getItem('cart')) || {};
        let cartTable = document.getElementById("cart-items");
        let couponTable = document.getElementById("coupon-items");
        let couponTitle = document.getElementById("coupon-title");
        let couponContent = document.getElementById("couponcontent");

        cartTable.innerHTML = "";
        couponTable.innerHTML = "";
        let subtotal = 0;
        let hasCoupons = false;
        
        Object.keys(cart).forEach((itemName) => {
            let item = cart[itemName];
            if (item.price) {
                let row = document.createElement("tr");
                row.innerHTML = `
                    <td>${itemName}</td>
                    <td>${item.quantity}</td>
                    <td>$${item.price.toFixed(2)}</td>
                `;
                row.addEventListener("click", () => $scope.removeItemFromCart(itemName));
                cartTable.appendChild(row);

                subtotal += item.price * item.quantity;
            }
            localStorage.setItem('cart', JSON.stringify(cart));
        });

        Object.keys(cart).forEach((itemName) => {
            let item = cart[itemName];
            if (!item.price) {
                hasCoupons = true;

                let eligibility = "Yes";
                if (subtotal < item.threshold) {
                    eligibility = "No";
                }

                let row = document.createElement("tr");
                row.innerHTML = `
                    <td style="font-size: 12px;">${itemName}</td>
                    <td>${eligibility}</td>
                    <td>$${item.discount.toFixed(2)}</td>
                `;
                row.addEventListener("click", () => $scope.removeItemFromCart(itemName));
                couponTable.appendChild(row);

                if (eligibility === "Yes") {
                    subtotal += item.discount;
                }
            }
        });

        document.getElementById("subtotal").innerText = `Subtotal: $${subtotal.toFixed(2)}`;

        if (hasCoupons) {
            couponTitle.style.display = "";
            couponContent.style.display = "";
        } else {
            couponTitle.style.display = "none";
            couponContent.style.display = "none";
        }
    }

    submitCartToCheckout = function() {
        const cart = JSON.parse(localStorage.getItem('cart')) || {};

        if (Object.keys(cart).length === 0) {
            alert("Cart is empty!");
            return;
        }

        for (let itemName in cart) {
            let item = cart[itemName];
            if (item.eligibility) {
                if (item.eligibility == "No") {
                    alert("Please Delete Ineligible Coupons");
                    return;
                }
            }
        };

        const form = document.createElement("form");
        form.method = "POST";
        form.action = "php/checkout.php";

        const input = document.createElement("input");
        input.type = "hidden";
        input.name = "cart_data";
        input.value = JSON.stringify(cart);

        form.appendChild(input);
        document.body.appendChild(form);
        form.submit();
    }

    document.querySelectorAll('.dropdown-toggle').forEach(dropBtn => {
        dropBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            const menu = this.nextElementSibling;
            menu.classList.toggle('show');

            // Close others if multiple dropdowns (optional)
            document.querySelectorAll('.dropdown-menu').forEach(m => {
                if (m !== menu) m.classList.remove('show');
            });

            // Close on outside click
            document.addEventListener('click', function outsideClickListener(event) {
                if (!menu.contains(event.target)) {
                    menu.classList.remove('show');
                    document.removeEventListener('click', outsideClickListener);
                }
            });
        });
    });
    $scope.updateCart()
})


app.controller('ServiceController', function($scope, $http) {

    // show coupons
    $http.get('api/getCoupons.php')
        .then(function(response) {
            $scope.items = response.data;
        }) 

    let cart = JSON.parse(localStorage.getItem('cart')) || {};
    localStorage.setItem('cart', JSON.stringify(cart));

    allowDrop = function(event) {
        event.preventDefault();
    }

    drag = function(event) {
        let item = event.target.closest('.product');
        if (!item) return;
        let itemName = item.getAttribute("data-coupon");
        let itemPrice = parseFloat(item.getAttribute("data-discount"));
        let threshold = parseFloat(item.getAttribute("data-threshold"))

        event.dataTransfer.setData("name", itemName);
        event.dataTransfer.setData("price", itemPrice);
        event.dataTransfer.setData("threshold", threshold);
    }

    drop = function (event) {
        event.preventDefault();
        let itemName = event.dataTransfer.getData("name");
        let itemPrice = parseFloat(event.dataTransfer.getData("price"));
        let threshold = parseFloat(event.dataTransfer.getData("threshold"));

        $scope.addCouponToCart(itemName, itemPrice, threshold);
    }

    $scope.addCouponToCart = function(couponName, discount, threshold) {
        let cart = JSON.parse(localStorage.getItem('cart')) || {};
        if (cart[couponName]) {

        } 
        
        else {
            for (let coupon in cart) {
                if (cart[coupon].discount) {
                    delete cart[coupon];
                }
            }

            let subTotal = parseFloat(document.getElementById("subtotal").textContent.split("$")[1]);

            if (subTotal < threshold) {
                cart[couponName] = { eligibility: "No", discount: -discount, threshold: threshold };
            }

            else {
                cart[couponName] = { eligibility: "Yes", discount: -discount, threshold: threshold };
            }
            
        }
        
        localStorage.setItem('cart', JSON.stringify(cart)); 
        $scope.updateCart();
    }

    $scope.updateCart = function() {
        let cart = JSON.parse(localStorage.getItem('cart')) || {};
        let cartTable = document.getElementById("cart-items");
        let couponTable = document.getElementById("coupon-items");
        let couponTitle = document.getElementById("coupon-title");
        let couponContent = document.getElementById("couponcontent");

        cartTable.innerHTML = "";
        couponTable.innerHTML = "";
        let subtotal = 0;
        let hasCoupons = false;

        Object.keys(cart).forEach((itemName) => {
            let item = cart[itemName];
            if (item.price) {
                let row = document.createElement("tr");
                row.innerHTML = `
                    <td>${itemName}</td>
                    <td>${item.quantity}</td>
                    <td>$${item.price.toFixed(2)}</td>
                `;
                row.addEventListener("click", () => $scope.removeItemFromCart(itemName));
                cartTable.appendChild(row);

                subtotal += item.price * item.quantity;
            }
            localStorage.setItem('cart', JSON.stringify(cart));
        });

        Object.keys(cart).forEach((itemName) => {
            let item = cart[itemName];
            if (!item.price) {
                hasCoupons = true;

                let eligibility = "Yes";
                if (subtotal < item.threshold) {
                    eligibility = "No";
                }

                let row = document.createElement("tr");
                row.innerHTML = `
                    <td style="font-size: 12px;">${itemName}</td>
                    <td>${eligibility}</td>
                    <td>$${item.discount.toFixed(2)}</td>
                `;
                row.addEventListener("click", () => $scope.removeItemFromCart(itemName));
                couponTable.appendChild(row);

                if (eligibility === "Yes") {
                    subtotal += item.discount;
                }
            }
        });

        document.getElementById("subtotal").innerText = `Subtotal: $${subtotal.toFixed(2)}`;
        if (hasCoupons) {
            couponTitle.style.display = "";
            couponContent.style.display = "";
        } else {
            couponTitle.style.display = "none";
            couponContent.style.display = "none";
        }
    }

    submitCartToCheckout = function() {
        const cart = JSON.parse(localStorage.getItem('cart')) || {};

        if (Object.keys(cart).length === 0) {
            alert("Cart is empty!");
            return;
        }

        for (let itemName in cart) {
            let item = cart[itemName];
            if (item.eligibility) {
                if (item.eligibility == "No") {
                    alert("Please Delete Ineligible Coupons");
                    return;
                }
            }
        };

        const form = document.createElement("form");
        form.method = "POST";
        form.action = "php/checkout.php";

        const input = document.createElement("input");
        input.type = "hidden";
        input.name = "cart_data";
        input.value = JSON.stringify(cart);

        form.appendChild(input);
        document.body.appendChild(form);
        form.submit();
    }

    document.querySelectorAll('.dropdown-toggle').forEach(dropBtn => {
        dropBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            const menu = this.nextElementSibling;
            menu.classList.toggle('show');

            // Close others if multiple dropdowns (optional)
            document.querySelectorAll('.dropdown-menu').forEach(m => {
                if (m !== menu) m.classList.remove('show');
            });

            // Close on outside click
            document.addEventListener('click', function outsideClickListener(event) {
                if (!menu.contains(event.target)) {
                    menu.classList.remove('show');
                    document.removeEventListener('click', outsideClickListener);
                }
            });
        });
    });

    // Initial render
    $scope.updateCart();
});

