<?php
include '../Model/db.php';

$result = $conn->query("SELECT * FROM Items");
$data = [];

while($row = $result->fetch_assoc()) {
    $data[] = [
        'id' => $row['item_id'],
        'name' => $row['item_name'],
        'price' => $row['item_price'],
        'image' => $row['item_image']
    ];
}
echo json_encode($data);
$conn->close();
?>