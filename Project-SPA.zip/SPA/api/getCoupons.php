<?php
include '../Model/db.php';

$result = $conn->query("SELECT * FROM Coupons");
$data = [];

while($row = $result->fetch_assoc()) {
    $data[] = [
        'description' => $row['coupon_description'],
        'discount' => $row['discount'],
        'min_threshold' => $row['min_threshold']
    ];
}
echo json_encode($data);
$conn->close();
?>