<?php
session_start();
include '../Model/db.php';

// Detect mode (Admin/User)
$admin = false;
$loggedin = false;
if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION["user_id"];
    $query = $conn->prepare("SELECT mode FROM Users WHERE user_id = ?");
    $query->bind_param("i", $userId);
    $query->execute();
    $query->bind_result($mode);
    $query->fetch();
    $query->close();
    if($mode === 'Admin'){
        $admin = true;
    }
    $loggedin = true;
}
echo json_encode(['loggedin' => $loggedin, 'admin' => $admin]);
$conn->close();
?>